<?php
add_action('rest_api_init', function () {
    register_rest_route('custom/v1', '/neo4j-config', array(
        'methods' => 'GET',
        'callback' => 'get_neo4j_config',
    ));
});

function get_neo4j_config() {
    return [
        'url' => NEO4J_HTTP_URL,
        'username' => NEO4J_USERNAME,
        'password' => NEO4J_PASSWORD,
    ];
}
